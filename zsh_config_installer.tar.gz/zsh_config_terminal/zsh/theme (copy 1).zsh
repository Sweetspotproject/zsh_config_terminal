source=~/.config/hypr/rose-pine-dawn.conf

##
## Aesthetic Night Colorscheme
##

# special
foreground='#d09b71' 
background='#2f2f2b' 

# black
color0='#2f2f2b'  
color8='#335358'  

# red
color1='#c24d45' 
color9='#c2534c' 

# green
color2='#84ac8c'  
color10='#857366'  

# yellow
color3='#d09b71'  
color11='#c2713c'  

# blue
color4='#636c5b'  
color12='#554d45'  

# magenta
color5='#c2534c'  
color13='#c24d45'  

# cyan
color6='#84ac8c'  
color14='#857366'  

# white
color7='#f2f4f5'  
color15='#f2f4f5'  

# vim:filetype=zsh
