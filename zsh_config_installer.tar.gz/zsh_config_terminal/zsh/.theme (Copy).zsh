##
## Aesthetic Night Colorscheme
##

# special
foreground='#edeff0'
background='#060809'

# black
color0='#232526'
color8='#2c2e2f'

# red
color1='#df5b61'
color9='#e8646a'

# green
color2='#78b892'
color10='#81c19b'

# yellow
color3='#de8f78'
color11='#e79881'

# blue
color4='#6791c9'
color12='#709ad2'

# magenta
color5='#bc83e3'
color13='#c58cec'

# cyan
color6='#67afc1'
color14='#70b8ca'

# white
color7='#e4e6e7'
color15='#f2f4f5'

# vim:filetype=zsh
