##
## Aesthetic Night Colorscheme
##

# special
foreground='#d4c6aa' 
background='#1e2326' 

# black
color0='#1e2326'  
color8='#1e2326'  

# red
color1='#e67e80' 
color9='#e67e80' 

# green
color2='#a7c080'  
color10='#a7c080'  

# yellow
color3='#dbbc7f'  
color11='#dbbc7f'  

# blue
color4='#7fbbb3'  
color12='#7fbbb3'  

# magenta
color5='#d699b6'  
color13='#d699b6'  

# cyan
color6='#83c092'  
color14='#83c092'  

# white
color7='#9da9a0'  
color15='#9da9a0'  

# vim:filetype=zsh
